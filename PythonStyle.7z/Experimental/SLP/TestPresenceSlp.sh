slptool findsrvs service:telnet.myorg

#  killall -v -s HUP -e slpd

#  /etc/init.d/slpd restart

