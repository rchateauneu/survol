#!/usr/bin/python

# Does not do anything, intentionaly.
# The processing is done in webslptool.py : But it could be done here.
