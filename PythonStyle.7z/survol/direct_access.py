#!/usr/bin/python

# TODO: There should be a form do go directly to an object such as a file:
# TODO: Select the entity type from a list, then enter its abbreviated URL,
# TODO: or have a a text cell for each parameter, with the parameter name.

