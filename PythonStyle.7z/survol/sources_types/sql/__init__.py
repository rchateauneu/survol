"""
SQL-related concepts
"""