# (1) Regarder l'arborescence des sous-processes. eventuellement on va y trouver la pile des scripts.
# (2) Scanner le script.
# (3) Afficher le PATH

