"""
Languages
"""

# Probably we could use some common code with CIM_Datafile, to statically examine the executable file,
# based on the language.
# Similarly to doxygen.
# On the other hand there are some specific stuff such as debugging a running process.