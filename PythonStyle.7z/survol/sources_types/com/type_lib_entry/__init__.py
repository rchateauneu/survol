"""
Component Object Model types library entry
"""

def Graphic_colorbg():
	return "#99FF99"


def EntityOntology():
	return ( ["Id"], )

