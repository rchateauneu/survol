"""
Sqlserver Data Source Name
"""

import lib_common
import lib_util
from sources_types import odbc as survol_odbc
# from sources_types.odbc import dsn as survol_odbc_dsn
from sources_types.odbc import CgiPropertyDsn
# from survol_odbc import *

def EntityOntology():
	# return ( ["Dsn"], )
	return ( [survol_odbc.CgiPropertyDsn()], )
	# return ( [CgiPropertyDsn()], )

def MakeUri(dsnName):
	# return lib_common.gUriGen.UriMakeFromDict("sqlserver/dsn", { "Dsn" : lib_util.EncodeUri(dsnName) })
	return lib_common.gUriGen.UriMakeFromDict("sqlserver/dsn", { survol_odbc.CgiPropertyDsn() : dsnName })
	# return lib_common.gUriGen.UriMakeFromDict("sqlserver/dsn", { CgiPropertyDsn() : dsnName })
