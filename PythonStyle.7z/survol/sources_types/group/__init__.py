"""
Operating system users group
"""

def EntityOntology():
    return ( ["Name"], )


