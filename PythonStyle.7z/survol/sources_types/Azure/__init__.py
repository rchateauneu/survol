"""
Azure concepts
"""

def Graphic_shape():
	return "egg"

def Graphic_colorfill():
	return "#CCCC33"

def Graphic_colorbg():
	return "#CCCC33"

def Graphic_border():
	return 0

def Graphic_is_rounded():
	return True
