#!/usr/bin/python

"""
Whois
"""

# TODO
# Also: Use geolocation of ip addresses.
# http://ip-api.com/docs/api:json

# https://rest.db.ripe.net/search.json?query-string=54.186.255.9