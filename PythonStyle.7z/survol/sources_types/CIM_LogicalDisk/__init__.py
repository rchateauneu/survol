def EntityOntology():
	return ( ["DeviceID"],)
