"""
Desktop Bus concepts
"""
