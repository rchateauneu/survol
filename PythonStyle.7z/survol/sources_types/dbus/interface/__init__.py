"""
Desktop Bus interface
"""

def EntityOntology():
	return ( ["Bus","Connect","Obj","Itf"], )

