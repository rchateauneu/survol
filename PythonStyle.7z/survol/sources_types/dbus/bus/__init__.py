"""
Desktop Bus
"""

def EntityOntology():
	return ( ["Bus"], )

