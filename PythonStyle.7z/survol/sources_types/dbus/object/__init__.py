"""
Desktop Bus object
"""

def EntityOntology():
	return ( ["Bus","Connect","Obj"], )

