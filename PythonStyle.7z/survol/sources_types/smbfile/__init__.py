"""
Files accessed via Samba protocol
"""

def EntityOntology():
	return ( ["Id"], )

